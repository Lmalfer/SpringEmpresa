package es.gestor.empleados.app.web.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import es.gestor.empleados.app.web.modelos.Empleados;


/**
 * Interfaz que proporciona métodos de acceso a datos para la entidad Empleados.
 * Utiliza Spring Data JPA y extiende JpaRepository para realizar operaciones CRUD en la base de datos.
 */
@Repository
public interface EmpleadosRepository extends JpaRepository<Empleados, String> {

	/**
	 * Verifica si existe un empleado con un DNI específico en la base de datos.
	 *
	 * @param dni El número de identificación del empleado.
	 * @return true si existe un empleado con el DNI proporcionado, false en caso contrario.
	 */
	public boolean existsByDni(String dni);

	/**
	 * Elimina un empleado de la base de datos por su número de identificación (DNI).
	 *
	 * @param dni El número de identificación del empleado a eliminar.
	 */
	public void deleteByDni(String dni);

	/**
	 * Busca un empleado por su número de identificación (DNI) en la base de datos.
	 *
	 * @param dni El número de identificación del empleado a buscar.
	 * @return Un Optional que contiene al empleado si se encuentra, o un Optional vacío si no se encuentra.
	 */
	Optional<Empleados> findByDni(String dni);
}
