package es.gestor.empleados.app.web.repository;

import java.util.UUID;

import es.gestor.empleados.app.web.modelos.Nomina;
import org.springframework.data.jpa.repository.JpaRepository;


/**
 * Interfaz que proporciona métodos de acceso a datos para la entidad Nomina.
 * Utiliza Spring Data JPA y extiende JpaRepository para realizar operaciones CRUD en la base de datos.
 */
public interface NominasRepository extends JpaRepository<Nomina, UUID> {

	/**
	 * Busca una nómina por el número de identificación (DNI) del empleado asociado.
	 *
	 * @param dni El número de identificación del empleado asociado a la nómina.
	 * @return La nómina asociada al empleado con el DNI proporcionado, si existe.
	 */
	Nomina findByEmpleado_Dni(String dni);
}
