package es.gestor.empleados.app.web.service;

import java.util.List;
import es.gestor.empleados.app.web.modelos.Empleados;
import es.gestor.empleados.app.web.modelos.Nomina;

/**
 * Interfaz que declara métodos para la gestión de empleados y nóminas.
 */
public interface EmpleadosService {

	/**
	 * Obtiene una lista de todos los empleados.
	 *
	 * @return Lista de empleados.
	 */
	List<Empleados> listarTodosLosEmpleados();

	/**
	 * Guarda un empleado en la base de datos.
	 *
	 * @param empleado El empleado a ser guardado.
	 * @return El empleado guardado.
	 */
	Empleados guardarEmpleado(Empleados empleado);

	/**
	 * Verifica si existe un empleado con el DNI proporcionado.
	 *
	 * @param dni El DNI del empleado a verificar.
	 * @return true si existe un empleado con ese DNI, false en caso contrario.
	 */
	boolean existeEmpleadoConDni(String dni);

	/**
	 * Obtiene un empleado dado su DNI.
	 *
	 * @param dni El DNI del empleado a obtener.
	 * @return El empleado con el DNI proporcionado, si existe.
	 */
	Empleados obtenerEmpleadoConDni(String dni);

	/**
	 * Actualiza la información de un empleado.
	 *
	 * @param empleado El empleado con la información actualizada.
	 * @return El empleado actualizado.
	 */
	Empleados actualizarEmpleado(Empleados empleado);

	/**
	 * Elimina un empleado de la base de datos dado su DNI.
	 *
	 * @param dni El DNI del empleado a eliminar.
	 */
	void eliminarEmpleado(String dni);

	/**
	 * Obtiene las nóminas de un empleado.
	 *
	 * @param empleado El empleado del que se obtienen las nóminas.
	 * @return Lista de nóminas del empleado proporcionado.
	 */
	List<Nomina> obtenerNominasDeEmpleado(Empleados empleado);
}
