package es.gestor.empleados.app.web.modelos;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.*;


/**
 * Clase que representa a un empleado en el sistema.
 * Contiene los atributos básicos de un empleado, como el DNI, nombre, sexo, categoría y años de experiencia.
 */
@Entity
@Table(name = "Empleados")
public class Empleados {

	@Id
	@Pattern(regexp = "\\d{8}[A-Z]", message = "El DNI debe tener 8 dígitos seguidos de una letra mayúscula")
	private String dni;

	@NotBlank(message = "El nombre no puede estar en blanco")
	@Size(max = 70, message = "El nombre no puede tener más de 70 caracteres")
	private String nombre;

	@Pattern(regexp = "[MF]", message = "El sexo debe ser 'M' o 'F'")
	private String sexo;

	@Min(value = 1, message = "La categoría debe ser al menos 1")
	@Max(value = 10, message = "La categoría no puede ser mayor que 10")
	private Integer categoria;

	@Min(value = 0, message = "Los años deben ser al menos 0")
	private Integer anyos;

	private Boolean deleted = false;

	/**
	 * Constructor por defecto de la clase Empleados.
	 */
	public Empleados() {
	}

	/**
	 * Constructor de la clase Empleados que recibe los parámetros básicos del empleado.
	 *
	 * @param dni       El DNI del empleado.
	 * @param nombre    El nombre del empleado.
	 * @param sexo      El sexo del empleado ('M' o 'F').
	 * @param categoria La categoría del empleado (de 1 a 10).
	 * @param anyos     Los años de experiencia del empleado.
	 * @throws DatosNoCorrectosException Si los datos proporcionados no son correctos según las validaciones.
	 */
	public Empleados(String dni, String nombre, String sexo, Integer categoria, Integer anyos) throws DatosNoCorrectosException {
		// Verificación de la categoría antes de asignarla
		if (categoria >= 1 && categoria <= 10) {
			this.categoria = categoria;
		} else {
			throw new DatosNoCorrectosException("Categoría incorrecta");
		}

		this.dni = dni;
		this.nombre = nombre;
		this.sexo = sexo;
		this.anyos = anyos;
		this.deleted = false;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public Integer getCategoria() {
		return categoria;
	}

	public void setCategoria(Integer categoria) {
		this.categoria = categoria;
	}

	public Integer getAnyos() {
		return anyos;
	}

	public void setAnyos(Integer anyos) {
		this.anyos = anyos;
	}

	public Boolean getDeleted() {
		return deleted;
	}


}
