package es.gestor.empleados.app.web.servicio;

import java.util.List;
import es.gestor.empleados.app.web.modelos.Empleados;
import es.gestor.empleados.app.web.modelos.Nomina;


public interface EmpleadosServicio {


	public List<Empleados> listarTodosLosEmpleados();


	public Empleados guardarEmpleado(Empleados empleado);


	boolean existeEmpleadoConDni(String dni);



	public Empleados obtenerEmpleadoConDni(String dni);


	public Empleados actualizarEmpleado(Empleados empleado);


	public void eliminarEmpleado(String dni);


	List<Nomina> obtenerNominasDeEmpleado(Empleados empleado);

}
