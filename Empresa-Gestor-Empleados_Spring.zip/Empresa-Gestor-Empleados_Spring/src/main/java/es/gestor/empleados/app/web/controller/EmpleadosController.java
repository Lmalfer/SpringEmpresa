package es.gestor.empleados.app.web.controller;

import java.util.List;

import es.gestor.empleados.app.web.modelos.Empleados;
import es.gestor.empleados.app.web.modelos.Nomina;
import es.gestor.empleados.app.web.service.EmpleadosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Controlador que maneja las operaciones relacionadas con los empleados.
 */

@Controller
public class EmpleadosController {


	@Autowired
	private EmpleadosService servicioEmpleado;

	/**
	 * Muestra la lista de todos los empleados.
	 *
	 * @param modelo El modelo utilizado para pasar datos a la vista.
	 * @return Nombre de la vista para listar los empleados.
	 */
	@GetMapping({ "/empleados/listar" })
	public String listarEmpleados(Model modelo) {
		modelo.addAttribute("listarEmpleados", servicioEmpleado.listarTodosLosEmpleados());
		return "listarempleados";
	}

	/**
	 * Muestra el formulario para registrar un nuevo empleado.
	 *
	 * @param modelo El modelo utilizado para pasar datos a la vista.
	 * @return Nombre de la vista para el formulario de registro de empleados.
	 */
	@GetMapping({ "/empleados/crear" })
	public String formRegistroEmpleado(Model modelo) {
		Empleados empleado = new Empleados();
		modelo.addAttribute("empleado", empleado);
		return "registroempleado";
	}

	/**
	 * Guarda un nuevo empleado en la base de datos.
	 *
	 * @param empleado El objeto Empleado a guardar.
	 * @param modelo   El modelo utilizado para pasar datos a la vista.
	 * @return Nombre de la vista para el formulario de registro de empleados.
	 */
	@PostMapping({ "/empleados" })
	public String guardarEmpleado(@ModelAttribute("empleado") Empleados empleado, Model modelo) {
		if (servicioEmpleado.existeEmpleadoConDni(empleado.getDni())) {
			modelo.addAttribute("error", "El empleado con DNI " + empleado.getDni() + " ya existe en la base de datos");
			return "registroempleado";
		}

		servicioEmpleado.guardarEmpleado(empleado);
		modelo.addAttribute("exito", "El empleado ha sido dado de alta exitosamente");
		return "registroempleado";
	}

	/**
	 * Muestra el formulario para editar los detalles de un empleado.
	 *
	 * @param dni     El DNI del empleado a editar.
	 * @param modelo  El modelo utilizado para pasar datos a la vista.
	 * @return Nombre de la vista para el formulario de edición de empleados.
	 */
	@GetMapping({ "/empleados/editar/{dni}" })
	public String FormEdita(@PathVariable String dni, Model modelo) {
		boolean empleadoExistente = servicioEmpleado.existeEmpleadoConDni(dni);
		if (empleadoExistente) {
			Empleados empleado = servicioEmpleado.obtenerEmpleadoConDni(dni);
			modelo.addAttribute("empleado", empleado);
			return "editarempleado";
		} else {
			modelo.addAttribute("error", "El empleado con DNI " + dni + " no existe.");
			return "redirect:/index";
		}
	}
	/**
	 * Actualiza los detalles de un empleado en la base de datos.
	 *
	 * @param dni                  El DNI del empleado a actualizar.
	 * @param empleado             El objeto Empleado con los nuevos detalles.
	 * @param modelo               El modelo utilizado para pasar datos a la vista.
	 * @param redirectAttributes   Los atributos de redirección.
	 * @return Redirección a la página de listado de empleados.
	 */
	@PostMapping("/empleados/{dni}")
	public String actualizaEmpleado(@PathVariable String dni, @ModelAttribute("empleado") Empleados empleado,
									 Model modelo, RedirectAttributes redirectAttributes) {
		boolean empleadoExistente = servicioEmpleado.existeEmpleadoConDni(dni);

		if (empleadoExistente) {
			if (!dni.equals(empleado.getDni()) && servicioEmpleado.existeEmpleadoConDni(empleado.getDni())) {
				modelo.addAttribute("error", "El DNI " + empleado.getDni() + " ya está registrado para otro empleado.");
				modelo.addAttribute("empleado", empleado);
				return "editarempleado";
			}

			servicioEmpleado.actualizarEmpleado(empleado);
			redirectAttributes.addFlashAttribute("exito", "El empleado con DNI " + dni + " ha sido editado exitosamente.");
		} else {
			redirectAttributes.addFlashAttribute("error", "El empleado con DNI " + dni + " no existe.");
			return "redirect:/empleados/listar";
		}

		return "redirect:/empleados/listar";
	}

	/**
	 * Elimina un empleado de la base de datos.
	 *
	 * @param dni                   El DNI del empleado a eliminar.
	 * @param redirectAttributes    Los atributos de redirección.
	 * @return Redirección a la página de listado de empleados.
	 */

	@GetMapping("/empleados/{dni}")
	public String eliminaEmpleado(@PathVariable String dni, RedirectAttributes redirectAttributes) {
		servicioEmpleado.eliminarEmpleado(dni);
		redirectAttributes.addFlashAttribute("exito", "El empleado con DNI " + dni + " ha sido eliminado exitosamente.");
		return "redirect:/empleados/listar";

	}

	/**
	 * Muestra el formulario para buscar salarios.
	 *
	 * @return Nombre de la vista para la búsqueda de salarios.
	 */

	@GetMapping("/buscar/salarios")
	public String formBuscarSalarios() {
		return "busquedasalario";
	}

	/**
	 * Busca el salario de un empleado según su DNI.
	 *
	 * @param dni    DNI del empleado para buscar el salario.
	 * @param modelo Modelo utilizado para pasar datos a la vista.
	 * @return Nombre de la vista para la búsqueda de salario con los resultados.
	 */

	@PostMapping("/buscar/salarios")
	public String buscarSalario(@RequestParam String dni, Model modelo) {
		Empleados empleado = servicioEmpleado.obtenerEmpleadoConDni(dni);

		if (empleado != null) {
			List<Nomina> nominas = servicioEmpleado.obtenerNominasDeEmpleado(empleado);
			if (!nominas.isEmpty()) {
				modelo.addAttribute("empleado", empleado);
				modelo.addAttribute("sueldo", nominas.get(0).getSueldo());
			} else {
				modelo.addAttribute("error", "No hay nóminas para el empleado con DNI " + dni);
			}
		} else {
			modelo.addAttribute("error", "No se encontró ningún empleado con DNI " + dni);
		}

		return "busquedasalario";
	}
	/**
	 * Muestra la página de inicio o el menú inicial.
	 *
	 * @return Nombre de la vista para el menú inicial.
	 */
	@GetMapping({ "/", "/index" })
	public String mostrarMenuInicial() {

		return "index";
	}
}