package es.gestor.empleados.app.web.repositorio;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import es.gestor.empleados.app.web.modelos.Empleados;



@Repository
public interface EmpleadosRepositorio extends JpaRepository<Empleados, String> {



	public boolean existsByDni(String dni);



	public void deleteByDni(String dni);



	Optional<Empleados> findByDni(String dni);

}
