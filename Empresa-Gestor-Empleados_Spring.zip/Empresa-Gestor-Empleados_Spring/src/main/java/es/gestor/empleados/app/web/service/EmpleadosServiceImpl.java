package es.gestor.empleados.app.web.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import es.gestor.empleados.app.web.modelos.Nomina;
import es.gestor.empleados.app.web.repository.EmpleadosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import es.gestor.empleados.app.web.modelos.Empleados;
import es.gestor.empleados.app.web.repository.NominasRepository;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;


/**
 * Implementación de la interfaz {@link EmpleadosService} que gestiona la lógica de negocio
 * relacionada con los empleados y las nóminas.
 */
@Service
public class EmpleadosServiceImpl implements EmpleadosService {

	@Autowired
	private EmpleadosRepository repositorioEmpleado;

	@Autowired
	private NominasRepository repositorioNominas;

	@Autowired
	private Validator validator;

	/**
	 * Obtiene una lista de todos los empleados.
	 *
	 * @return Lista de todos los empleados.
	 */
	@Override
	public List<Empleados> listarTodosLosEmpleados() {
		return repositorioEmpleado.findAll();
	}

	/**
	 * Guarda un nuevo empleado en la base de datos junto con su respectiva nómina.
	 *
	 * @param empleado El empleado a ser guardado.
	 * @return El empleado guardado.
	 * @throws RuntimeException Si el empleado ya está registrado o si ocurren violaciones de validación.
	 */
	@Override
	public Empleados guardarEmpleado(Empleados empleado) {

		if (existeEmpleadoConDni(empleado.getDni())) {
			throw new RuntimeException("¡Error! El empleado con DNI " + empleado.getDni() + " ya está registrado.");
		}

		Set<ConstraintViolation<Empleados>> violations = validator.validate(empleado);

		if (violations.isEmpty()) {
			Empleados empleadoGuardado = repositorioEmpleado.save(empleado);

			Nomina nomina = new Nomina(empleadoGuardado);
			repositorioNominas.save(nomina);
			return empleadoGuardado;
		} else {
			throw new RuntimeException("Error de validación: " + violations.toString());
		}
	}

	/**
	 * Verifica si existe un empleado en la base de datos con un DNI específico.
	 *
	 * @param dni El número de DNI a verificar.
	 * @return true si existe un empleado con el DNI proporcionado, false en caso contrario.
	 */
	@Override
	public boolean existeEmpleadoConDni(String dni) {

		return repositorioEmpleado.existsByDni(dni);
	}


	/**
	 * Obtiene un empleado de la base de datos con un DNI específico.
	 *
	 * @param dni El número de DNI del empleado a buscar.
	 * @return El empleado encontrado con el DNI proporcionado o null si no se encuentra.
	 */
	@Override

	public Empleados obtenerEmpleadoConDni(String dni) {
		Optional<Empleados> optionalEmpleado = repositorioEmpleado.findByDni(dni);

		return optionalEmpleado.orElse(null);
	}

	/**
	 * Actualiza la información de un empleado en la base de datos.
	 *
	 * @param empleado El objeto Empleados con la información actualizada.
	 * @return El empleado actualizado.
	 * @throws RuntimeException Si el empleado no está registrado o si hay violaciones de validación.
	 */
	@Override
	public Empleados actualizarEmpleado(Empleados empleado) {
		if (!repositorioEmpleado.existsByDni(empleado.getDni())) {
			throw new RuntimeException("¡Error! El empleado con DNI " + empleado.getDni() + " no está registrado.");
		}
		Set<ConstraintViolation<Empleados>> violations = validator.validate(empleado);

		if (violations.isEmpty()) {
			Nomina nomina = repositorioNominas.findByEmpleado_Dni(empleado.getDni());

			if (nomina != null) {
				nomina.setSueldo(nomina.calcularSueldo(empleado));
				repositorioNominas.save(nomina);
			} else {
				throw new RuntimeException(
						"¡Error! La nómina para el empleado con DNI " + empleado.getDni() + " no está registrada.");
			}
			return repositorioEmpleado.save(empleado);
		} else {
			throw new RuntimeException("Error de validación: " + violations.toString());
		}
	}
	/**
	 * Elimina un empleado de la base de datos junto con su respectiva nómina.
	 *
	 * @param dni El número de DNI del empleado a eliminar.
	 * @throws RuntimeException Si el empleado no está registrado.
	 */
	@Override
	@Transactional
	public void eliminarEmpleado(String dni) {
		Optional<Empleados> empleado = repositorioEmpleado.findByDni(dni);
		if (empleado == null) {
			throw new RuntimeException("¡Error! El empleado con DNI " + dni + " no está registrado.");
		}
		Nomina nomina = repositorioNominas.findByEmpleado_Dni(dni);
		if (nomina != null) {
			repositorioNominas.delete(nomina);
		}
		repositorioEmpleado.deleteByDni(dni);
	}

	/**
	 * Obtiene las nóminas asociadas a un empleado en la base de datos.
	 *
	 * @param empleado El objeto Empleados para el cual se buscan las nóminas.
	 * @return Una lista con la(s) nómina(s) del empleado o una lista vacía si no hay nóminas o el empleado es nulo.
	 */
	@Override
	public List<Nomina> obtenerNominasDeEmpleado(Empleados empleado) {
		if (empleado != null) {
			Nomina nomina = repositorioNominas.findByEmpleado_Dni(empleado.getDni());

			return Collections.singletonList(nomina);
		} else {
			return Collections.emptyList();
		}
	}
}