package es.gestor.empleados.app.web.repositorio;

import java.util.UUID;

import es.gestor.empleados.app.web.modelos.Nomina;
import org.springframework.data.jpa.repository.JpaRepository;



public interface NominasRepositorio extends JpaRepository<Nomina, UUID> {


	
	Nomina findByEmpleado_Dni(String dni);
}
