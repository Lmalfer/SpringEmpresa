package es.gestor.empleados.app.web.controlador;

import java.util.List;

import es.gestor.empleados.app.web.modelos.Empleados;
import es.gestor.empleados.app.web.modelos.Nomina;
import es.gestor.empleados.app.web.servicio.EmpleadosServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;



@Controller
public class EmpleadosControlador {
	

	@Autowired
	private EmpleadosServicio servicioEmpleado;
	
	@Autowired

	

	@GetMapping({ "/", "/menuInicial" }) // Lo tengo puesto asi para que si no hay la ruta / me coja menuInicial
	public String mostrarMenuInicial() {
		
		return "/menuInicial";
	}
	

	@GetMapping({ "/empleados/listar" })
	public String listarEmpleados(Model modelo) {
		modelo.addAttribute("listarEmpleados", servicioEmpleado.listarTodosLosEmpleados());
		return "listarEmpleados";
	}
	

	@GetMapping({ "/empleados/crear" })
	public String mostrarFormularioRegistrarEmpleado(Model modelo) {
	    Empleados empleado = new Empleados();
	    modelo.addAttribute("empleado", empleado);
	    return "crearEmpleado";
	}
	

	@PostMapping({ "/empleados" })
	public String guardarEmpleado(@ModelAttribute("empleado") Empleados empleado, Model modelo) {
	    // Verificar si el empleado ya existe en la base de datos
	    if (servicioEmpleado.existeEmpleadoConDni(empleado.getDni())) {
	        modelo.addAttribute("error", "El empleado con DNI " + empleado.getDni() + " ya existe en la base de datos");
	        return "crearEmpleado";
	    }

	    servicioEmpleado.guardarEmpleado(empleado);
	    modelo.addAttribute("exito", "El empleado ha sido dado de alta exitosamente");
	    return "crearEmpleado";
	}
	

	@GetMapping({ "/empleados/editar/{dni}" })
	public String mostrarFormularioDeEditar(@PathVariable String dni, Model modelo) {
	    boolean empleadoExistente = servicioEmpleado.existeEmpleadoConDni(dni);
	    if (empleadoExistente) {
	        Empleados empleado = servicioEmpleado.obtenerEmpleadoConDni(dni);
	        modelo.addAttribute("empleado", empleado);
	        return "editarEmpleado";
	    } else {
	        modelo.addAttribute("error", "El empleado con DNI " + dni + " no existe.");
	        return "redirect:/menuInicial";
	    }
	}

	
	@PostMapping("/empleados/{dni}")
	public String actualizarEmpleado(@PathVariable String dni, @ModelAttribute("empleado") Empleados empleado,
	        Model modelo, RedirectAttributes redirectAttributes) {
	    boolean empleadoExistente = servicioEmpleado.existeEmpleadoConDni(dni);

	    if (empleadoExistente) {
	        servicioEmpleado.actualizarEmpleado(empleado);
	        redirectAttributes.addFlashAttribute("exito", "El empleado con DNI " + dni + " ha sido editado exitosamente.");
	    } else {
	        redirectAttributes.addFlashAttribute("error", "El empleado con DNI " + dni + " no existe.");
	        return "redirect:/empleados/listar"; // Si hay un error que no lo creo, redirijo directamente a la lista sin pasar por la vista de editar
	    }

	    return "redirect:/empleados/listar";
	}

	
	@GetMapping("/empleados/{dni}")
	public String eliminarEmpleado(@PathVariable String dni, RedirectAttributes redirectAttributes) {
		servicioEmpleado.eliminarEmpleado(dni);
		redirectAttributes.addFlashAttribute("exito", "El empleado con DNI " + dni + " ha sido eliminado exitosamente.");
		return "redirect:/empleados/listar";

	}
	

	
	@GetMapping("/buscar/salarios")
	public String mostrarFormularioBuscarSalarios() {
		return "buscarSalarios";
	}
	

	@PostMapping("/buscar/salarios")
	public String buscarSalario(@RequestParam String dni, Model modelo) {
	    Empleados empleado = servicioEmpleado.obtenerEmpleadoConDni(dni);

	    if (empleado != null) {
	        List<Nomina> nominas = servicioEmpleado.obtenerNominasDeEmpleado(empleado);
	        if (!nominas.isEmpty()) {
	            modelo.addAttribute("empleado", empleado);
	            modelo.addAttribute("sueldo", nominas.get(0).getSueldo());
	        } else {
	            modelo.addAttribute("error", "No hay nóminas para el empleado con DNI " + dni);
	        }
	    } else {
	        modelo.addAttribute("error", "No se encontró ningún empleado con DNI " + dni);
	    }

	    return "buscarSalarios";
	}
}
