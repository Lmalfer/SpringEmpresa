package es.gestor.empleados.app.web.modelos;

/**
 * Excepción personalizada para representar casos en los que los datos no son correctos.
 * Puede ser utilizada para manejar situaciones específicas de error relacionadas con datos incorrectos.
 */
public class DatosNoCorrectosException extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor que crea una instancia de la excepción con un mensaje descriptivo.
	 *
	 * @param mensaje El mensaje descriptivo que indica la razón por la que se lanzó la excepción.
	 */
	public DatosNoCorrectosException(String mensaje) {
		super(mensaje);
	}
}

