package es.gestor.empleados.app.web.modelos;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "Nominas")
public class Nomina {

	/**
	 * Identificador único de la nómina.
	 */

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID id;


	@ManyToOne
	@JoinColumn(name = "dni_empleado", referencedColumnName = "dni")
	private Empleados empleado;


	private int sueldo;



	public Nomina() {
	}


	public Nomina(Empleados empleado) {
		this.empleado = empleado;
		this.sueldo = calcularSueldo(empleado);
	}


	public UUID getId() {
		return id;
	}


	public void setId(UUID id) {
		this.id = id;
	}



	public Empleados getEmpleado() {
		return empleado;
	}


	public void setEmpleado(Empleados empleado) {
		this.empleado = empleado;
		this.sueldo = calcularSueldo(empleado);
	}



	public int getSueldo() {
		return sueldo;
	}

	public void setSueldo(int sueldo) {
		this.sueldo = sueldo;
	}



	public int calcularSueldo(Empleados e) {
		int[] SUELDO_BASE = { 50000, 70000, 90000, 110000, 130000, 150000, 170000, 190000, 210000, 230000 };
		return SUELDO_BASE[e.getCategoria() - 1] + 5000 * e.getAnyos();
	}

}
