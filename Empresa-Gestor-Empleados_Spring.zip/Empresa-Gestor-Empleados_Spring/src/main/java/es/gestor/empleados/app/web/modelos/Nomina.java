package es.gestor.empleados.app.web.modelos;

import jakarta.persistence.*;
import java.util.UUID;

/**
 * Clase que representa la nómina de un empleado en el sistema.
 * Contiene detalles como el identificador único, el empleado asociado y el sueldo.
 */
@Entity
@Table(name = "Nominas")
public class Nomina {

	/**
	 * Identificador único de la nómina.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private UUID id;

	/**
	 * Empleado asociado a la nómina.
	 */
	@ManyToOne
	@JoinColumn(name = "dni_empleado", referencedColumnName = "dni")
	private Empleados empleado;

	/**
	 * Sueldo asociado a la nómina.
	 */
	private int sueldo;

	/**
	 * Constructor por defecto de la clase Nomina.
	 */
	public Nomina() {
	}

	/**
	 * Constructor de la clase Nomina que recibe un empleado y calcula su sueldo correspondiente.
	 *
	 * @param empleado El empleado asociado a la nómina.
	 */
	public Nomina(Empleados empleado) {
		this.empleado = empleado;
		this.sueldo = calcularSueldo(empleado);
	}


	public UUID getId() {
		return id;
	}


	public void setId(UUID id) {
		this.id = id;
	}



	public Empleados getEmpleado() {
		return empleado;
	}


	public void setEmpleado(Empleados empleado) {
		this.empleado = empleado;
		this.sueldo = calcularSueldo(empleado);
	}



	public int getSueldo() {
		return sueldo;
	}

	public void setSueldo(int sueldo) {
		this.sueldo = sueldo;
	}

	/**
	 * Método para calcular el sueldo de un empleado basado en la categoría y los años de experiencia.
	 *
	 * @param e El empleado para el cual se calcula el sueldo.
	 * @return El sueldo calculado para el empleado.
	 */
	public int calcularSueldo(Empleados e) {
		int[] SUELDO_BASE = {50000, 70000, 90000, 110000, 130000, 150000, 170000, 190000, 210000, 230000};
		return SUELDO_BASE[e.getCategoria() - 1] + 5000 * e.getAnyos();
	}
}