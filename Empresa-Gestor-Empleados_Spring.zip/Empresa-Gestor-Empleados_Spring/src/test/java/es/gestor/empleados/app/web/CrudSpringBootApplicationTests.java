package es.gestor.empleados.app.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
